#include <iostream>

using namespace std;


int main()
{
    //Declaring the display mat and initializing
    char disp_matrix[9][6],player;
    for(int i=0;i<9;i++)
        for(int j=0;j<6;j++)
            disp_matrix[i][j]='*';
    //Declaring the backend_mat to stote the values of the elements present in a box
    int backend_mat[9][6]={0},inc=1,row,col;
    while(1)
    {
        int flag=-1;
        //IF ODD -> PLAYER 'A' ,ELSE -> PLAYER 'B'
    (inc%2==1)?player='a':player='b';
    cout<<"\nEnter the position player "<<player<<"\n";
    //Obtaining the position
    cin>>row>>col;
    //Condition to prevent overwriting of A by B or B by A
    if( (player=='a' && disp_matrix[row][col]!='b') || (player=='b' && disp_matrix[row][col]!='a') )
    {
     inc++;
     //Counting the no of times the values entered
    backend_mat[row][col]++;
    //Storing the entered values
    disp_matrix[row][col]=player;
  //  cout<<row<<" "<<col<<"\n";
  //  cout<<backend_mat[row][col]<<"-"<<disp_matrix[row][col]<<"\n";

    //Displaying the display matrix.!!
    cout<<"   ";
        for(int j=0;j<6;j++)
            cout<<j<<" ";
        cout<<"\n";
        for(int i=0;i<9;i++)
            {
                cout<<i<<"  ";
                for(int j=0;j<6;j++)
                    {
                    cout<<disp_matrix[i][j]<<" ";
                    }
                cout<<"\n";
            }
            cout<<"\n\n***************\n\n";
    //Displaying the display matrix with backend matrix!!
    cout<<"   ";
        for(int j=0;j<6;j++)
            cout<<j<<"   ";
        cout<<"\n";
        for(int i=0;i<9;i++)
            {
                cout<<i<<"  ";
                for(int j=0;j<6;j++)
                    {
                    cout<<disp_matrix[i][j]<<"."<<backend_mat[i][j];
                    }
                cout<<"\n";
            }
        //MAIN CALCULATION FOR THE CRIICAL MASS..!!
        //CONDITION FOR THE CORNER ELEMENTS CRITICAL MASS = 2..!!

             if(row==0 && col==0 && backend_mat[0][0] == 2)
             {
                 disp_matrix[0][0]='*';
                 backend_mat[0][0]=0;

                 disp_matrix[0][1]=player;
                 backend_mat[0][1]++;

                 disp_matrix[1][0]=player;
                 backend_mat[1][0]++;
             }
             else if(row==0 && col==5 && backend_mat[0][5] == 2 )
             {
                 disp_matrix[0][5]='*';
                 backend_mat[0][5]=0;

                 disp_matrix[0][4]=player;
                 backend_mat[0][4]++;

                 disp_matrix[1][5]=player;
                 backend_mat[1][5]++;


             }
             else if(row==8 && col==0 && backend_mat[8][0] == 2)
             {
                 disp_matrix[8][0]='*';
                 backend_mat[8][0]=0;

                 disp_matrix[7][0]=player;
                 backend_mat[7][0]++;

                 disp_matrix[8][1]=player;
                 backend_mat[8][1]++;
             }
             else if(row==8 && col==5 && backend_mat[8][5] == 2)
             {
                 disp_matrix[8][5]='*';
                 backend_mat[8][5]=0;

                 disp_matrix[8][4]=player;
                 backend_mat[8][4]++;

                 disp_matrix[7][5]=player;
                 backend_mat[7][5]++;
             }
        //CONDITION FOR THE EDGE ELEMENTS CRITICAL MASS = 3..!!
            //for 1st column
             else if(col==0 && row!=0 && row!=8)
              {
                if(backend_mat[row][col]==3)
                {
                    backend_mat[row][col]=0;
                    disp_matrix[row][col]='*';

                    backend_mat[row+1][col]++;
                    disp_matrix[row+1][col]=player;

                    backend_mat[row-1][col]++;
                    disp_matrix[row-1][col]=player;

                    backend_mat[row][col+1]++;
                    disp_matrix[row][col+1]=player;
                }
              }
              //for last column
              else if(col==5 && row!=0 && row!=8)
              {
                if(backend_mat[row][col]==3)
                {
                    backend_mat[row][col]=0;
                    disp_matrix[row][col]='*';

                    backend_mat[row+1][col]++;
                    disp_matrix[row+1][col]=player;

                    backend_mat[row-1][col]++;
                    disp_matrix[row-1][col]=player;

                    backend_mat[row][col-1]++;
                    disp_matrix[row][col-1]=player;

                }
              }
              //for 1st row
              else if(row==0 && col!=0 &&  col!=5)
              {
                if(backend_mat[row][col]==3)
                {
                    backend_mat[row][col]=0;
                    disp_matrix[row][col]='*';

                    backend_mat[row][col+1]++;
                    disp_matrix[row][col+1]=player;

                    backend_mat[row][col-1]++;
                    disp_matrix[row][col-1]=player;

                    backend_mat[row+1][col]++;
                    disp_matrix[row+1][col]=player;
                }
              }
              //for 8th row
              else if(row==8 && col!=0 && col!=5)
              {
                if(backend_mat[row][col]==3)
                {
                    backend_mat[row][col]=0;
                    disp_matrix[row][col]='*';

                    backend_mat[row][col+1]++;
                    disp_matrix[row][col+1]=player;

                    backend_mat[row][col-1]++;
                    disp_matrix[row][col-1]=player;

                    backend_mat[row-1][col]++;
                    disp_matrix[row-1][col]=player;
                }
              }


            //Calculation for central elements, CRITICAL MASS == 4
            else
            {
                if(backend_mat[row][col]==4)
                {
                disp_matrix[row][col]='*';
                backend_mat[row][col]='0';

                backend_mat[row-1][col]++;
                disp_matrix[row-1][col]=player;

                backend_mat[row+1][col]++;
                disp_matrix[row+1][col]=player;

                backend_mat[row][col-1]++;
                disp_matrix[row][col-1]=player;

                backend_mat[row][col+1]++;
                disp_matrix[row][col+1]=player;
                }
            }
            //If the matrix COMPRISES ONLY OF 'a' AND '*' THEN PLAYER A WON THE GAME..!
            for(int i=0;i<9;i++)
            {
                for(int j=0;j<6;j++)
                {
                    if(disp_matrix[i][j]=='a' || disp_matrix[i][j]=='*')
                    {
                        flag=1;
                    }
                    else
                    {
                        flag=-1;
                        break;
                    }
                }
                if(flag==-1)
                    break;
            }
            if(flag==1 && inc>2)
            {
                cout<<"PLAYER A WINS..!!\n";
                //DISPLAYING THE FINAL MATRIX
                for(int i=0;i<9;i++)
                    {
                    for(int j=0;j<6;j++)
                        {
                            cout<<disp_matrix[i][j]<<" ";
                        }
                    cout<<"\n";
                    }
                return 0;
            }
  // IF THE MATRIX COMPRISES ONLY OF 'b' AND '*' THEN PLAYER B WON THE GAME..!
            for(int i=0;i<9;i++)
            {
                for(int j=0;j<6;j++)
                {
                    if(disp_matrix[i][j]=='b' || disp_matrix[i][j]=='*')
                    {
                        flag=2;
                    }
                    else
                    {
                        flag=-1;
                        break;
                    }
                }
                if(flag==-1)
                    break;
            }

            if(flag==2 && inc>2)
            {
                cout<<"PLAYER B WINS..!!\n";
                //DISPLAYING THE DISPLAY_MATRIX ALONG WITH THE BACKEND MATRIX.!!
                for(int i=0;i<9;i++)
                    {
                    for(int j=0;j<6;j++)
                        {
                            cout<<disp_matrix[i][j]<<" ";
                        }
                    cout<<"\n";
                    }
                return 0;
            }
    }
    else
        cout<<"ENTER SOME OTHER POSITION >!!!!\n";
    }
        return 0;
}
